package com.bioid.authenticator.base.network.bioid.webservice;

/**
 * Will be thrown if the user has not been enrolled.
 */
public class NoEnrollmentException extends RuntimeException {

    public NoEnrollmentException() {
    }
}

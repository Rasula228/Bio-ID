package com.bioid.authenticator.base.network.bioid.webservice;

/**
 * Will be thrown if the uploaded image did contain multiple faces.
 */
public class MultipleFacesFoundException extends RuntimeException {
}

package com.bioid.authenticator.base.network.bioid.webservice;

/**
 * Will be thrown if the provided credentials are incorrect.
 */
public class WrongCredentialsException extends RuntimeException{
}

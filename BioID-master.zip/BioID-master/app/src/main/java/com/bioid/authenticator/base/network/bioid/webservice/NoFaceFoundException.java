package com.bioid.authenticator.base.network.bioid.webservice;

/**
 * Will be thrown if the uploaded image did not contain a face.
 */
public class NoFaceFoundException extends RuntimeException {
}

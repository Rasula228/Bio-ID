package com.bioid.authenticator.base.network.bioid.webservice;

/**
 * Biometric task.
 */
public enum Task {
    Verification, Enrollment, Liveness, PhotoVerify
}

package com.bioid.authenticator.base.functional;

/**
 * Functional interface from Java 8.
 */
public interface Supplier<T> {
    T get();
}

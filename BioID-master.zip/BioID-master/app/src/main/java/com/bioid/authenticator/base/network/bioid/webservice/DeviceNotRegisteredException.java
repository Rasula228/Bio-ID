package com.bioid.authenticator.base.network.bioid.webservice;

/**
 * Will be thrown if the device is not registered anymore.
 */
public class DeviceNotRegisteredException extends RuntimeException {
}

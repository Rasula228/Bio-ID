package com.bioid.authenticator.base.network.bioid.webservice;

/**
 * Specifies the trait-handling of BWS.
 */
@SuppressWarnings("unused")
public enum Trait {
    Face, Voice, Periocular
}

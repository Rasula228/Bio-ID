package com.bioid.authenticator.base.network.bioid.webservice;

/**
 * Will be thrown if no valid images have been uploaded.
 */
public class NoSamplesException extends RuntimeException {

    public NoSamplesException() {
    }
}

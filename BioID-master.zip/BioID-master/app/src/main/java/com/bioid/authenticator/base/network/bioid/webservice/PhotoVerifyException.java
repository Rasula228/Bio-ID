package com.bioid.authenticator.base.network.bioid.webservice;

class PhotoVerifyException extends RuntimeException {
    PhotoVerifyException(String message) {
        super(message);
    }
}
